フォント名：たぬえいカクポップタイ（英語名：TanueiKakuPop）
ファイル名：TanueiKakuPop.otf, TanueiKaKupop-NoLap.otf
形式：OpenType形式
制作者：たぬきフォント（たぬき侍） https://tanukifont.com
最新バージョン：1.0

フォントの詳細内容についてはhttps://tanukifont.com/tanuei-kaku-popを参照してください。